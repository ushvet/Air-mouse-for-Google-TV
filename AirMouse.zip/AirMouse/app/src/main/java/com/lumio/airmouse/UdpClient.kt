package com.lumio.airmouse

import android.os.Handler
import android.os.HandlerThread
import android.os.Looper
import android.util.Log
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetAddress
import java.net.NetworkInterface
import java.net.SocketTimeoutException
import kotlin.concurrent.thread

/** Phone side: sends commands to the TV and finds it on the network. */
class UdpClient {

    private val main = Handler(Looper.getMainLooper())
    private val worker = HandlerThread("airmouse-send").apply { start() }
    private val handler = Handler(worker.looper)
    private var socket: DatagramSocket? = null

    @Volatile var target: InetAddress? = null
        private set

    fun send(msg: String) {
        val t = target ?: return
        handler.post {
            try {
                val s = socket ?: DatagramSocket().also { socket = it }
                val b = msg.toByteArray(Charsets.UTF_8)
                s.send(DatagramPacket(b, b.size, t, Protocol.PORT))
            } catch (e: Exception) {
                Log.w(TAG, "send failed", e)
            }
        }
    }

    fun setTarget(host: String, done: (Boolean) -> Unit) {
        handler.post {
            val addr = try { InetAddress.getByName(host.trim()) } catch (e: Exception) { null }
            if (addr != null) target = addr
            main.post { done(addr != null) }
        }
    }

    /** Broadcasts "AIRMOUSE?" and returns (tvName, ip) of the first TV that answers. */
    fun discover(callback: (Pair<String, String>?) -> Unit) {
        thread(name = "airmouse-discover", isDaemon = true) {
            var result: Pair<String, String>? = null
            try {
                DatagramSocket().use { s ->
                    s.broadcast = true
                    s.soTimeout = 1000
                    val ask = Protocol.DISCOVER.toByteArray()
                    val buf = ByteArray(256)
                    for (attempt in 0 until 3) {
                        for (addr in broadcastAddresses()) {
                            try { s.send(DatagramPacket(ask, ask.size, addr, Protocol.PORT)) } catch (_: Exception) {}
                        }
                        try {
                            val p = DatagramPacket(buf, buf.size)
                            s.receive(p)
                            val txt = String(p.data, 0, p.length, Charsets.UTF_8)
                            if (txt.startsWith(Protocol.HERE)) {
                                val name = txt.removePrefix(Protocol.HERE).trim().ifEmpty { "TV" }
                                result = name to (p.address.hostAddress ?: "")
                                break
                            }
                        } catch (_: SocketTimeoutException) {
                        }
                    }
                }
            } catch (e: Exception) {
                Log.w(TAG, "discover failed", e)
            }
            main.post { callback(result) }
        }
    }

    private fun broadcastAddresses(): List<InetAddress> {
        val list = mutableListOf<InetAddress>()
        try { list += InetAddress.getByName("255.255.255.255") } catch (_: Exception) {}
        try {
            for (ni in NetworkInterface.getNetworkInterfaces()) {
                if (!ni.isUp || ni.isLoopback) continue
                for (ia in ni.interfaceAddresses) ia.broadcast?.let { list += it }
            }
        } catch (_: Exception) {}
        return list.distinct()
    }

    fun close() {
        worker.quitSafely()
        socket?.close()
    }

    companion object { private const val TAG = "AirMouse" }
}
