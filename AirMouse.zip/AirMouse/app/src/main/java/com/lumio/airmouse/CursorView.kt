package com.lumio.airmouse

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.os.SystemClock
import android.view.View
import kotlin.math.min

/** The round pointer drawn on top of everything on the TV. */
class CursorView(context: Context) : View(context) {

    private val shadow = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0x55000000
        style = Paint.Style.FILL
    }
    private val fill = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = Color.WHITE
        style = Paint.Style.FILL
    }
    private val ring = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF1E88E5.toInt()
        style = Paint.Style.STROKE
    }

    private var pressedUntil = 0L

    override fun onDraw(canvas: Canvas) {
        val cx = width / 2f
        val cy = height / 2f
        val r = min(width, height) / 2f
        val pressed = SystemClock.uptimeMillis() < pressedUntil
        val inner = r * 0.72f * (if (pressed) 0.65f else 1f)
        ring.strokeWidth = r * 0.2f
        canvas.drawCircle(cx, cy, r * 0.98f, shadow)
        canvas.drawCircle(cx, cy, inner, fill)
        canvas.drawCircle(cx, cy, inner, ring)
    }

    /** Short "squeeze" animation when a click happens. */
    fun pulse() {
        pressedUntil = SystemClock.uptimeMillis() + 150
        invalidate()
        postDelayed({ invalidate() }, 170)
    }
}
