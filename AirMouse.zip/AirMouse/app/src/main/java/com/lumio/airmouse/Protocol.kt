package com.lumio.airmouse

/**
 * Tiny text protocol sent over UDP on the home Wi-Fi.
 *
 *  M dx dy   move cursor by dx/dy pixels
 *  C         click (tap) at cursor
 *  LC        long press at cursor
 *  S n       scroll vertically (n > 0 = down, n < 0 = up)
 *  SH n      scroll horizontally (n > 0 = right)
 *  B / H     Back / Home
 *  V+ V- VM  volume up / down / mute
 *  P         play-pause
 *  CENTER    move cursor to the middle of the screen
 */
object Protocol {
    const val PORT = 50505
    const val DISCOVER = "AIRMOUSE?"
    const val HERE = "AIRMOUSE!"
}
