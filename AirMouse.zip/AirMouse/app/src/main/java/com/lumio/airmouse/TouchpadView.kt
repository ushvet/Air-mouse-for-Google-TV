package com.lumio.airmouse

import android.annotation.SuppressLint
import android.content.Context
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.os.SystemClock
import android.view.HapticFeedbackConstants
import android.view.MotionEvent
import android.view.View
import android.view.ViewConfiguration
import kotlin.math.hypot

/**
 * Laptop-style touchpad on the phone:
 *  drag = move cursor, tap = click, hold = long press, two-finger drag = scroll.
 */
class TouchpadView(context: Context, private val listener: Listener) : View(context) {

    interface Listener {
        fun onMove(dx: Float, dy: Float)
        fun onTap()
        fun onLongPress()
        fun onScroll(notches: Int)
    }

    private val density = resources.displayMetrics.density
    private val slop = ViewConfiguration.get(context).scaledTouchSlop
    private val scrollStep = 40 * density
    private val speed = 1.8f

    private val bg = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = 0xFF1E242B.toInt() }
    private val hint = Paint(Paint.ANTI_ALIAS_FLAG).apply {
        color = 0xFF78909C.toInt()
        textSize = 14 * density
        textAlign = Paint.Align.CENTER
    }
    private val rect = RectF()

    private var lastX = 0f
    private var lastY = 0f
    private var startX = 0f
    private var startY = 0f
    private var downAt = 0L
    private var moved = false
    private var twoFinger = false
    private var longFired = false
    private var lastScrollY = 0f
    private var scrollAcc = 0f

    private val longPress = Runnable {
        if (!moved && !twoFinger) {
            longFired = true
            performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            listener.onLongPress()
        }
    }

    override fun onDraw(canvas: Canvas) {
        rect.set(0f, 0f, width.toFloat(), height.toFloat())
        canvas.drawRoundRect(rect, 20 * density, 20 * density, bg)
        val lines = listOf("TOUCHPAD", "Tap = click   •   Drag = move", "Hold = long press   •   2 fingers = scroll")
        var y = height / 2f - (lines.size - 1) * hint.textSize * 0.9f
        for (l in lines) {
            canvas.drawText(l, width / 2f, y, hint)
            y += hint.textSize * 1.8f
        }
    }

    private fun avgY(e: MotionEvent): Float {
        var sum = 0f
        for (i in 0 until e.pointerCount) sum += e.getY(i)
        return sum / e.pointerCount
    }

    @SuppressLint("ClickableViewAccessibility")
    override fun onTouchEvent(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                lastX = e.x; lastY = e.y
                startX = e.x; startY = e.y
                downAt = SystemClock.uptimeMillis()
                moved = false; twoFinger = false; longFired = false
                postDelayed(longPress, 600)
            }
            MotionEvent.ACTION_POINTER_DOWN -> {
                twoFinger = true
                removeCallbacks(longPress)
                lastScrollY = avgY(e)
                scrollAcc = 0f
            }
            MotionEvent.ACTION_MOVE -> {
                if (twoFinger) {
                    if (e.pointerCount >= 2) {
                        val ay = avgY(e)
                        scrollAcc += lastScrollY - ay   // fingers up = scroll down
                        lastScrollY = ay
                        while (scrollAcc > scrollStep) { listener.onScroll(1); scrollAcc -= scrollStep }
                        while (scrollAcc < -scrollStep) { listener.onScroll(-1); scrollAcc += scrollStep }
                    }
                } else {
                    if (!moved && hypot(e.x - startX, e.y - startY) > slop) {
                        moved = true
                        removeCallbacks(longPress)
                    }
                    if (moved) listener.onMove((e.x - lastX) * speed, (e.y - lastY) * speed)
                    lastX = e.x; lastY = e.y
                }
            }
            MotionEvent.ACTION_UP -> {
                removeCallbacks(longPress)
                if (!moved && !twoFinger && !longFired && SystemClock.uptimeMillis() - downAt < 350) {
                    performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
                    listener.onTap()
                }
            }
            MotionEvent.ACTION_CANCEL -> removeCallbacks(longPress)
        }
        return true
    }
}
