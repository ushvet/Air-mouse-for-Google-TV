package com.lumio.airmouse

import android.app.Activity
import android.app.UiModeManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import android.provider.Settings
import android.util.TypedValue
import android.view.Gravity
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import java.net.Inet4Address
import java.net.NetworkInterface

/**
 * Entry point. On a phone it opens the remote; on the TV it shows the
 * setup screen for the pointer service.
 */
class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var ipText: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (!isTv()) {
            startActivity(Intent(this, RemoteActivity::class.java))
            finish()
            return
        }
        buildTvUi()
    }

    private fun isTv(): Boolean {
        val ui = getSystemService(Context.UI_MODE_SERVICE) as UiModeManager
        return ui.currentModeType == Configuration.UI_MODE_TYPE_TELEVISION ||
            packageManager.hasSystemFeature(PackageManager.FEATURE_LEANBACK)
    }

    private fun dp(v: Int) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun text(s: String, sizeSp: Float, color: Int = Color.WHITE) = TextView(this).apply {
        text = s
        textSize = sizeSp
        setTextColor(color)
        setPadding(0, dp(6), 0, dp(6))
    }

    private fun buildTvUi() {
        val col = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(48), dp(32), dp(48), dp(32))
            setBackgroundColor(0xFF101418.toInt())
        }
        col.addView(text("Air Mouse — TV receiver", 30f))
        status = text("", 20f)
        col.addView(status)
        ipText = text("", 18f, 0xFFB0BEC5.toInt())
        col.addView(ipText)

        val open = Button(this).apply {
            text = "Open Accessibility settings"
            setOnClickListener { openAccessibilitySettings() }
        }
        col.addView(open, LinearLayout.LayoutParams(
            LinearLayout.LayoutParams.WRAP_CONTENT, LinearLayout.LayoutParams.WRAP_CONTENT
        ).apply { topMargin = dp(12); gravity = Gravity.START })

        col.addView(text(
            "How to turn it on:\n" +
                "1. Press the button above (or go to Settings → System → Accessibility).\n" +
                "2. Choose \"Air Mouse\" and switch it ON. Confirm the warning.\n" +
                "3. Open Air Mouse on your phone. It finds this TV automatically.\n\n" +
                "Phone and TV must be on the same Wi-Fi network.",
            17f, 0xFFCFD8DC.toInt()
        ))
        col.addView(text(
            "If Air Mouse is missing from the Accessibility list, turn it on from a computer with ADB:\n" +
                "adb shell settings put secure enabled_accessibility_services " +
                "com.lumio.airmouse/com.lumio.airmouse.AirMouseService\n" +
                "adb shell settings put secure accessibility_enabled 1",
            14f, 0xFF90A4AE.toInt()
        ))

        setContentView(ScrollView(this).apply { addView(col) })
        open.requestFocus()
    }

    override fun onResume() {
        super.onResume()
        if (!::status.isInitialized) return
        if (AirMouseService.isEnabled(this)) {
            status.text = "✅ Pointer service is ON. Open Air Mouse on your phone."
            status.setTextColor(0xFFA5D6A7.toInt())
        } else {
            status.text = "⚠️ Pointer service is OFF. Turn it on below."
            status.setTextColor(0xFFFFCC80.toInt())
        }
        ipText.text = "TV address: ${localIp()}   (port ${Protocol.PORT})"
    }

    private fun openAccessibilitySettings() {
        try {
            startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } catch (e: Exception) {
            startActivity(Intent(Settings.ACTION_SETTINGS))
        }
    }

    private fun localIp(): String = try {
        NetworkInterface.getNetworkInterfaces().toList()
            .flatMap { it.inetAddresses.toList() }
            .firstOrNull { !it.isLoopbackAddress && it is Inet4Address && it.isSiteLocalAddress }
            ?.hostAddress ?: "not connected"
    } catch (e: Exception) {
        "unknown"
    }
}
