package com.lumio.airmouse

import android.app.Activity
import android.app.AlertDialog
import android.content.Context
import android.content.SharedPreferences
import android.hardware.Sensor
import android.hardware.SensorEvent
import android.hardware.SensorEventListener
import android.hardware.SensorManager
import android.os.Bundle
import android.text.InputType
import android.util.TypedValue
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.LinearLayout
import android.widget.SeekBar
import android.widget.Switch
import android.widget.TextView
import kotlin.math.abs
import kotlin.math.sqrt

/** Phone remote: gyro "air pointer", touchpad and TV buttons. */
class RemoteActivity : Activity(), SensorEventListener {

    private lateinit var prefs: SharedPreferences
    private lateinit var client: UdpClient
    private lateinit var status: TextView

    private lateinit var sensors: SensorManager
    private var gyro: Sensor? = null
    private var gravitySensor: Sensor? = null
    private val gravity = floatArrayOf(0f, 0f, 9.81f)
    private var lastGyroTs = 0L

    private var gyroOn = true
    private var pxPerRadian = 3600f
    private var accX = 0f
    private var accY = 0f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        prefs = getSharedPreferences("airmouse", Context.MODE_PRIVATE)
        client = UdpClient()

        sensors = getSystemService(Context.SENSOR_SERVICE) as SensorManager
        gyro = sensors.getDefaultSensor(Sensor.TYPE_GYROSCOPE)
        gravitySensor = sensors.getDefaultSensor(Sensor.TYPE_GRAVITY)
            ?: sensors.getDefaultSensor(Sensor.TYPE_ACCELEROMETER)
        gyroOn = gyro != null && prefs.getBoolean("gyro", true)

        buildUi()

        val lastIp = prefs.getString("ip", null)
        if (lastIp != null) connectTo(lastIp, prefs.getString("name", "TV") ?: "TV", quiet = true)
        findTv()
    }

    // ------------------------------------------------------------------ UI

    private fun dp(v: Int) =
        TypedValue.applyDimension(TypedValue.COMPLEX_UNIT_DIP, v.toFloat(), resources.displayMetrics).toInt()

    private fun button(label: String, onClick: () -> Unit) = Button(this).apply {
        text = label
        isAllCaps = false
        textSize = 16f
        setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.VIRTUAL_KEY)
            onClick()
        }
    }

    private fun row(vararg views: View) = LinearLayout(this).apply {
        orientation = LinearLayout.HORIZONTAL
        for (v in views) addView(v, LinearLayout.LayoutParams(0, dp(56), 1f).apply {
            marginStart = dp(3); marginEnd = dp(3)
        })
    }

    private fun buildUi() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(14), dp(24), dp(14), dp(14))
            setBackgroundColor(0xFF101418.toInt())
        }

        status = TextView(this).apply {
            textSize = 15f
            setTextColor(0xFFCFD8DC.toInt())
            setPadding(dp(4), 0, dp(4), dp(8))
        }
        root.addView(status)

        root.addView(row(
            button("Find TV") { findTv() },
            button("Enter IP") { askForIp() },
            button("Center") { client.send("CENTER") }
        ))

        val gyroSwitch = Switch(this).apply {
            text = if (gyro != null) "Air pointer (move your phone)" else "No gyroscope: use the touchpad"
            textSize = 15f
            setTextColor(0xFFFFFFFF.toInt())
            isEnabled = gyro != null
            isChecked = gyroOn
            setPadding(dp(4), dp(12), dp(4), dp(4))
            setOnCheckedChangeListener { _, checked ->
                gyroOn = checked
                prefs.edit().putBoolean("gyro", checked).apply()
                registerSensors()
            }
        }
        root.addView(gyroSwitch)

        val speedLabel = TextView(this).apply {
            text = "Pointer speed"
            setTextColor(0xFF90A4AE.toInt())
            setPadding(dp(4), dp(4), dp(4), 0)
        }
        root.addView(speedLabel)
        val speed = SeekBar(this).apply {
            max = 100
            progress = prefs.getInt("speed", 30)
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar, p: Int, fromUser: Boolean) {
                    pxPerRadian = 1500f + p * 70f
                    prefs.edit().putInt("speed", p).apply()
                }
                override fun onStartTrackingTouch(sb: SeekBar) {}
                override fun onStopTrackingTouch(sb: SeekBar) {}
            })
        }
        pxPerRadian = 1500f + speed.progress * 70f
        root.addView(speed)

        val pad = TouchpadView(this, object : TouchpadView.Listener {
            override fun onMove(dx: Float, dy: Float) = sendMove(dx, dy)
            override fun onTap() = client.send("C")
            override fun onLongPress() = client.send("LC")
            override fun onScroll(notches: Int) = client.send("S $notches")
        })
        root.addView(pad, LinearLayout.LayoutParams(LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f).apply {
            topMargin = dp(8); bottomMargin = dp(10)
        })

        root.addView(row(
            button("◀  Back") { client.send("B") },
            button("⌂  Home") { client.send("H") },
            button("⏯  Play") { client.send("P") }
        ))
        root.addView(row(
            button("Vol −") { client.send("V-") },
            button("Mute") { client.send("VM") },
            button("Vol +") { client.send("V+") }
        ))
        root.addView(row(
            button("▲ Scroll") { client.send("S -1") },
            button("Hold") { client.send("LC") },
            button("▼ Scroll") { client.send("S 1") }
        ))

        setContentView(root)
    }

    // ------------------------------------------------------------ connection

    private fun findTv() {
        if (client.target == null) status.text = "Searching for your TV…"
        client.discover { found ->
            if (found != null) {
                connectTo(found.second, found.first)
            } else if (client.target == null) {
                status.text = "TV not found. Check that the Air Mouse service is ON on the TV and " +
                    "both devices are on the same Wi-Fi, or tap Enter IP."
            }
        }
    }

    private fun connectTo(ip: String, name: String, quiet: Boolean = false) {
        client.setTarget(ip) { ok ->
            if (ok) {
                prefs.edit().putString("ip", ip).putString("name", name).apply()
                status.text = "📺 Controlling $name ($ip)"
            } else if (!quiet) {
                status.text = "Couldn't use address \"$ip\""
            }
        }
    }

    private fun askForIp() {
        val input = EditText(this).apply {
            hint = "e.g. 192.168.1.25"
            inputType = InputType.TYPE_CLASS_TEXT or InputType.TYPE_TEXT_VARIATION_URI
            setText(prefs.getString("ip", ""))
        }
        AlertDialog.Builder(this)
            .setTitle("TV address")
            .setMessage("Shown on the Air Mouse screen on your TV.")
            .setView(input)
            .setPositiveButton("Connect") { _, _ ->
                val ip = input.text.toString().trim()
                if (ip.isNotEmpty()) connectTo(ip, "TV")
            }
            .setNegativeButton("Cancel", null)
            .show()
    }

    // ---------------------------------------------------------------- motion

    private fun sendMove(fx: Float, fy: Float) {
        accX += fx
        accY += fy
        val ix = accX.toInt()
        val iy = accY.toInt()
        if (ix != 0 || iy != 0) {
            accX -= ix
            accY -= iy
            client.send("M $ix $iy")
        }
    }

    private fun registerSensors() {
        sensors.unregisterListener(this)
        lastGyroTs = 0L
        if (!gyroOn) return
        gyro?.let { sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
        gravitySensor?.let { sensors.registerListener(this, it, SensorManager.SENSOR_DELAY_GAME) }
    }

    override fun onResume() {
        super.onResume()
        registerSensors()
    }

    override fun onPause() {
        sensors.unregisterListener(this)
        super.onPause()
    }

    override fun onDestroy() {
        client.close()
        super.onDestroy()
    }

    override fun onAccuracyChanged(sensor: Sensor?, accuracy: Int) {}

    override fun onSensorChanged(e: SensorEvent) {
        when (e.sensor.type) {
            Sensor.TYPE_GRAVITY -> for (i in 0..2) gravity[i] = e.values[i]
            Sensor.TYPE_ACCELEROMETER -> for (i in 0..2) gravity[i] = 0.9f * gravity[i] + 0.1f * e.values[i]
            Sensor.TYPE_GYROSCOPE -> onGyro(e)
        }
    }

    /**
     * Converts phone rotation into cursor motion. Uses gravity so it works
     * whether you hold the phone flat or tilted, like a remote:
     *  turn left/right (yaw)  → cursor left/right
     *  tilt up/down  (pitch)  → cursor up/down
     */
    private fun onGyro(e: SensorEvent) {
        if (lastGyroTs == 0L) { lastGyroTs = e.timestamp; return }
        val dt = (e.timestamp - lastGyroTs) / 1_000_000_000f
        lastGyroTs = e.timestamp
        if (dt <= 0f || dt > 0.1f) return

        val wx = e.values[0]; val wy = e.values[1]; val wz = e.values[2]
        val gn = sqrt(gravity[0] * gravity[0] + gravity[1] * gravity[1] + gravity[2] * gravity[2])
        if (gn < 1f) return
        val ux = gravity[0] / gn; val uy = gravity[1] / gn; val uz = gravity[2] / gn

        // Rotation around the vertical axis.
        var yaw = wx * ux + wy * uy + wz * uz

        // Rotation around the horizontal "right" axis of where the phone points.
        var fx = -uy * ux; var fy = 1f - uy * uy; var fz = -uy * uz   // phone's top edge, made horizontal
        val fn = sqrt(fx * fx + fy * fy + fz * fz)
        var pitch: Float
        if (fn < 0.2f) {
            pitch = wx
        } else {
            fx /= fn; fy /= fn; fz /= fn
            val rx = fy * uz - fz * uy
            val ry = fz * ux - fx * uz
            val rz = fx * uy - fy * ux
            pitch = wx * rx + wy * ry + wz * rz
        }

        // Ignore tiny hand tremor.
        if (abs(yaw) < 0.03f) yaw = 0f
        if (abs(pitch) < 0.03f) pitch = 0f
        if (yaw == 0f && pitch == 0f) return

        sendMove(-yaw * pxPerRadian * dt, -pitch * pxPerRadian * dt)
    }
}
