# Air Mouse for Google TV (Lumio Vision 7)

Turns your phone into a magic-remote-style pointer for your TV. **The same app installs on both devices**:

- **Phone:** opens the remote. Move the phone to move the cursor. It also has a touchpad (tap = click, drag = move, two fingers = scroll) and buttons for Back, Home, Play/Pause, Volume and Scroll.
- **TV:** shows a setup screen. A background accessibility service draws the cursor and clicks wherever it points.

Both devices must be on the **same Wi-Fi**. The phone finds the TV automatically (UDP port 50505).

## 1. Get the APK (no PC needed)

1. Create a free GitHub account and a new repository.
2. Upload all files from this folder, including the hidden `.github` folder.
3. Open the **Actions** tab. The "Build APK" job runs on its own (or tap *Run workflow*).
4. When it shows a green tick, open the run and download **AirMouse-apk**. It's a zip; unzip it to get `app-debug.apk`.

*With a PC:* open the folder in Android Studio and choose Build → Build APK(s).

## 2. Install on your phone
Open `app-debug.apk` and allow "Install unknown apps" when asked.

## 3. Install on the TV
Easiest way:
1. On the TV, install **Send Files to TV** and a file manager (e.g. **File Commander**) from the Play Store.
2. On the TV: Settings → Privacy (or Device Preferences) → Security & restrictions → **Unknown sources**, then allow the file manager.
3. Send the APK from your phone with *Send Files to TV*, then open it in the file manager on the TV to install.

(Or with ADB: `adb connect <tv-ip>` then `adb install app-debug.apk`.)

## 4. Turn on the pointer on the TV
Open **Air Mouse** on the TV, press **Open Accessibility settings**, choose **Air Mouse** and switch it **ON**.
If it's missing from that list, run these from a computer:

```
adb shell settings put secure enabled_accessibility_services com.lumio.airmouse/com.lumio.airmouse.AirMouseService
adb shell settings put secure accessibility_enabled 1
```

You only do this once. The service starts automatically after a reboot.

## 5. Use it
Open Air Mouse on the phone. It shows "Controlling <TV name>". Hold the phone like a remote:
- turn left/right → cursor left/right
- tilt up/down → cursor up/down
- tap the touchpad → click

Use **Pointer speed** to adjust sensitivity, and **Center** if the cursor gets lost. The cursor hides after 6 seconds without movement.

## Limits
- Clicks are sent as screen taps. Most apps handle them, but a few TV apps built only for arrow keys may ignore them. Keep your Minion remote for those.
- Volume controls the TV's own speakers. A soundbar connected over HDMI may not respond.
- Google TV can't be given arrow-key presses by an app without root, so there's no D-pad on the phone.
