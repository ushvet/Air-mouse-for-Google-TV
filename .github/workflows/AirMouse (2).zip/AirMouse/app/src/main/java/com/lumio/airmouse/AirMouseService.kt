package com.lumio.airmouse

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.ComponentName
import android.content.Context
import android.hardware.display.DisplayManager
import android.graphics.Path
import android.graphics.PixelFormat
import android.media.AudioManager
import android.net.wifi.WifiManager
import android.os.Build
import android.os.Handler
import android.os.Looper
import android.provider.Settings
import android.util.DisplayMetrics
import android.util.Log
import android.view.Display
import android.view.Gravity
import android.view.KeyEvent
import android.view.View
import android.view.WindowManager
import android.view.accessibility.AccessibilityEvent
import java.net.DatagramPacket
import java.net.DatagramSocket
import java.net.InetSocketAddress
import kotlin.concurrent.thread

/**
 * Runs on the Google TV. Listens for commands from the phone, draws a cursor
 * overlay, and injects taps / swipes / Back / Home at the cursor position.
 */
class AirMouseService : AccessibilityService() {

    private val main = Handler(Looper.getMainLooper())
    private var wm: WindowManager? = null
    private var cursor: CursorView? = null
    private var lp: WindowManager.LayoutParams? = null

    private var size = 36
    private var screenW = 1920
    private var screenH = 1080
    private var x = 960f
    private var y = 540f

    @Volatile private var running = false
    private var socket: DatagramSocket? = null
    private var multicastLock: WifiManager.MulticastLock? = null

    private val hideCursor = Runnable { cursor?.visibility = View.GONE }

    override fun onServiceConnected() {
        super.onServiceConnected()
        installCrashLogger(this)
        try {
            setUp()
            log(this, "Service started OK (${screenW}x${screenH})")
        } catch (t: Throwable) {
            log(this, "Start failed: " + Log.getStackTraceString(t))
        }
    }

    private fun setUp() {
        readScreenSize()
        x = screenW / 2f
        y = screenH / 2f
        size = (screenH / 30).coerceAtLeast(24)

        // Start listening first, so the phone can connect even if the overlay fails.
        startServer()

        val w = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        wm = w
        val view = CursorView(this).apply { visibility = View.GONE }
        val params = WindowManager.LayoutParams(
            size, size,
            WindowManager.LayoutParams.TYPE_ACCESSIBILITY_OVERLAY,
            WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE or
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN or
                WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
            PixelFormat.TRANSLUCENT
        ).apply { gravity = Gravity.TOP or Gravity.START }

        cursor = view
        lp = params
        positionCursor()
        try {
            w.addView(view, params)
        } catch (t: Throwable) {
            log(this, "Cursor overlay failed: " + Log.getStackTraceString(t))
            cursor = null
        }
    }

    private fun readScreenSize() {
        try {
            val dm = getSystemService(Context.DISPLAY_SERVICE) as DisplayManager
            val display = dm.getDisplay(Display.DEFAULT_DISPLAY)
            val m = DisplayMetrics()
            @Suppress("DEPRECATION")
            display.getRealMetrics(m)
            if (m.widthPixels > 0 && m.heightPixels > 0) {
                screenW = m.widthPixels
                screenH = m.heightPixels
                return
            }
        } catch (t: Throwable) {
            log(this, "Display size: " + t)
        }
        val m = resources.displayMetrics
        screenW = m.widthPixels.coerceAtLeast(1280)
        screenH = m.heightPixels.coerceAtLeast(720)
    }

    // ---------------------------------------------------------------- network

    private fun startServer() {
        running = true
        try {
            val wifi = applicationContext.getSystemService(Context.WIFI_SERVICE) as WifiManager
            multicastLock = wifi.createMulticastLock("airmouse").apply {
                setReferenceCounted(false)
                acquire()
            }
        } catch (e: Exception) {
            Log.w(TAG, "No multicast lock", e)
        }

        thread(name = "airmouse-server", isDaemon = true) {
            try {
                val s = DatagramSocket(null)
                s.reuseAddress = true
                s.broadcast = true
                s.bind(InetSocketAddress(Protocol.PORT))
                socket = s
                val buf = ByteArray(512)
                while (running) {
                    val p = DatagramPacket(buf, buf.size)
                    s.receive(p)
                    val msg = String(p.data, 0, p.length, Charsets.UTF_8).trim()
                    if (msg == Protocol.DISCOVER) {
                        val reply = "${Protocol.HERE} ${Build.MODEL}".toByteArray()
                        s.send(DatagramPacket(reply, reply.size, p.address, p.port))
                    } else if (msg.isNotEmpty()) {
                        main.post {
                            try { handle(msg) } catch (t: Throwable) { log(this, "Command '$msg' failed: $t") }
                        }
                    }
                }
            } catch (e: Exception) {
                if (running) log(this, "Network stopped: $e")
            }
        }
    }

    private fun handle(msg: String) {
        val parts = msg.split(' ')
        fun num(i: Int) = parts.getOrNull(i)?.toFloatOrNull() ?: 0f
        when (parts[0]) {
            "M" -> move(num(1), num(2))
            "C" -> click(40)
            "LC" -> click(800)
            "S" -> scroll(num(1), vertical = true)
            "SH" -> scroll(num(1), vertical = false)
            "B" -> performGlobalAction(GLOBAL_ACTION_BACK)
            "H" -> performGlobalAction(GLOBAL_ACTION_HOME)
            "R" -> performGlobalAction(GLOBAL_ACTION_RECENTS)
            "V+" -> volume(AudioManager.ADJUST_RAISE)
            "V-" -> volume(AudioManager.ADJUST_LOWER)
            "VM" -> volume(AudioManager.ADJUST_TOGGLE_MUTE)
            "P" -> mediaKey(KeyEvent.KEYCODE_MEDIA_PLAY_PAUSE)
            "CENTER" -> {
                x = screenW / 2f
                y = screenH / 2f
                updateCursor()
            }
        }
    }

    // ---------------------------------------------------------------- cursor

    private fun move(dx: Float, dy: Float) {
        x = (x + dx).coerceIn(0f, screenW - 1f)
        y = (y + dy).coerceIn(0f, screenH - 1f)
        updateCursor()
    }

    private fun positionCursor() {
        lp?.let {
            it.x = (x - size / 2f).toInt()
            it.y = (y - size / 2f).toInt()
        }
    }

    private fun updateCursor() {
        positionCursor()
        val v = cursor
        val p = lp
        if (v != null && p != null) {
            try {
                wm?.updateViewLayout(v, p)
            } catch (_: Exception) {
            }
        }
        showCursor()
    }

    private fun showCursor() {
        cursor?.visibility = View.VISIBLE
        main.removeCallbacks(hideCursor)
        main.postDelayed(hideCursor, 6000)
    }

    // ---------------------------------------------------------------- actions

    private fun click(durationMs: Long) {
        showCursor()
        cursor?.pulse()
        val path = Path().apply { moveTo(x, y) }
        dispatch(path, durationMs)
    }

    /** amount > 0 scrolls content down/right (finger swipes up/left). */
    private fun scroll(amount: Float, vertical: Boolean) {
        if (amount == 0f) return
        showCursor()
        val length = (if (vertical) screenH else screenW).toFloat()
        val max = length - 2f
        val d = (length * 0.25f * amount).coerceIn(-max * 0.8f, max * 0.8f)

        var start = if (vertical) y else x
        var end = start - d
        if (end < 1f) { start += 1f - end; end = 1f }
        if (end > max) { start -= end - max; end = max }
        start = start.coerceIn(1f, max)

        val path = Path()
        if (vertical) {
            path.moveTo(x, start)
            path.lineTo(x, end)
        } else {
            path.moveTo(start, y)
            path.lineTo(end, y)
        }
        dispatch(path, 220)
    }

    private fun dispatch(path: Path, durationMs: Long) {
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, durationMs))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun volume(direction: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.adjustStreamVolume(AudioManager.STREAM_MUSIC, direction, AudioManager.FLAG_SHOW_UI)
    }

    private fun mediaKey(code: Int) {
        val am = getSystemService(Context.AUDIO_SERVICE) as AudioManager
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_DOWN, code))
        am.dispatchMediaKeyEvent(KeyEvent(KeyEvent.ACTION_UP, code))
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}

    override fun onInterrupt() {}

    override fun onDestroy() {
        running = false
        socket?.close()
        try { multicastLock?.release() } catch (_: Exception) {}
        cursor?.let { try { wm?.removeView(it) } catch (_: Exception) {} }
        main.removeCallbacksAndMessages(null)
        super.onDestroy()
    }

    companion object {
        private const val TAG = "AirMouse"
        private const val PREFS = "airmouse_tv"

        fun isEnabled(ctx: Context): Boolean {
            val list = Settings.Secure.getString(
                ctx.contentResolver,
                Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES
            ) ?: return false
            val me = ComponentName(ctx, AirMouseService::class.java)
            return list.split(':').any { ComponentName.unflattenFromString(it) == me }
        }

        /** Saves a status / error line that the TV setup screen shows. */
        fun log(ctx: Context, line: String) {
            Log.i(TAG, line)
            val time = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
            ctx.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit().putString("last", "[$time] $line").commit()
        }

        fun lastLog(ctx: Context): String? =
            ctx.getSharedPreferences(PREFS, Context.MODE_PRIVATE).getString("last", null)

        private var loggerInstalled = false

        /** If the app crashes anyway, record why before Android kills it. */
        fun installCrashLogger(ctx: Context) {
            if (loggerInstalled) return
            loggerInstalled = true
            val app = ctx.applicationContext
            val previous = Thread.getDefaultUncaughtExceptionHandler()
            Thread.setDefaultUncaughtExceptionHandler { t, e ->
                try { log(app, "CRASH: " + Log.getStackTraceString(e)) } catch (_: Throwable) {}
                previous?.uncaughtException(t, e)
            }
        }
    }
}
