plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

android {
    namespace = "com.lumio.airmouse"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.lumio.airmouse"
        minSdk = 24          // gesture injection needs Android 7+
        targetSdk = 34
        versionCode = 2
        versionName = "1.1"
    }

    // Fixed key so every new build installs over the previous one.
    signingConfigs {
        create("fixed") {
            storeFile = file("airmouse.keystore")
            storePassword = "airmouse"
            keyAlias = "airmouse"
            keyPassword = "airmouse"
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("fixed")
        }
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("fixed")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}

// No extra libraries needed — plain Android framework only.
